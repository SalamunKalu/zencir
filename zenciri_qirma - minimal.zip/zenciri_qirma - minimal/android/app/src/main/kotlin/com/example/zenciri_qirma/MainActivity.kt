package com.example.zenciri_qirma

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
