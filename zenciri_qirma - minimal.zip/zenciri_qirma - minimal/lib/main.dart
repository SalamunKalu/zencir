/*
ZƏNCİRİ QIRMAQ - Flutter app

Bu fayl `main.dart` üçün tam tətbiq nümunəsidir. Aşağıda həmçinin `pubspec.yaml` və APK yaratmaq/cihazınıza yükləmək üçün addımlar yerləşir.

Qısa funksionallıq:
- Task (vəzifə) yaratmaq: ad, hədəf gün sayı, gündə planlanan dəqiqə
- Hər gün üçün icra olub/olmadığını qeyd etmək və icra edilibsə sərf olunan dəqiqəni yazmaq
- Təyin olunan günlər bitdikdə ümumi sərf olunan dəqiqənin göstərilməsi
- Lokal saxlanma: shared_preferences istifadə olunur (JSON kimi)
- Modern Material 3 UI, animasiyalar, progress göstəriciləri

QURAŞDIRMA / APK YARATMAQ (qısa):
1) Kompüterinizdə Flutter SDK quraşdırın: https://flutter.dev/docs/get-started/install
2) Layihə yaradın və bu `main.dart`-ı `lib/main.dart`-a yapışdırın.
3) `pubspec.yaml`-ı aşağıdakı kimi tənzimləyin (dependencies hissəsi):

# pubspec.yaml (vacib hissə)
name: zenciri_qirmamaq
description: Simple chain-break tracker
publish_to: 'none'
version: 1.0.0+1
environment:
  sdk: '>=2.18.0 <3.0.0'

dependencies:
  flutter:
    sdk: flutter
  shared_preferences: ^2.1.0

  cupertino_icons: ^1.0.2

flutter:
  uses-material-design: true

4) Terminalda layihə kökündə çalışın:
   flutter pub get
   flutter build apk --release
   (və ya test üçün `flutter run` ilə cihazda çalışdırın)

5) Xiaomi Poco X6 cihazına yükləmək üçün:
   - Cihazda "Developer options" aktiv edin və USB debugging açın
   - USB ilə qoşun və `flutter devices` ilə cihazı yoxlayın
   - `flutter install` və ya `flutter build apk --release` sonra APK-nı cihazda açın


-- Aşağıda `lib/main.dart` məzmunu başlayır --
*/

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(MyApp(prefs: prefs));
}

class MyApp extends StatelessWidget {
  final SharedPreferences prefs;
  const MyApp({super.key, required this.prefs});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Zənciri Qırmamaq',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: HomePage(prefs: prefs),
    );
  }
}

// MODELS
class Task {
  String id;
  String title;
  DateTime createdAt;
  int targetDays;
  int plannedMinutesPerDay;
  Map<int, int> records; // dayIndex (0..targetDays-1) -> minutes spent (0 = not done)

  Task({
    required this.id,
    required this.title,
    required this.createdAt,
    required this.targetDays,
    required this.plannedMinutesPerDay,
    Map<int, int>? records,
  }) : records = records ?? {};

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'createdAt': createdAt.toIso8601String(),
        'targetDays': targetDays,
        'plannedMinutesPerDay': plannedMinutesPerDay,
        'records': records.map((k, v) => MapEntry(k.toString(), v)),
      };

  static Task fromJson(Map<String, dynamic> j) {
    final recRaw = (j['records'] ?? {}) as Map<String, dynamic>;
    final rec = recRaw.map((k, v) => MapEntry(int.parse(k), (v as num).toInt()));
    return Task(
        id: j['id'],
        title: j['title'],
        createdAt: DateTime.parse(j['createdAt']),
        targetDays: (j['targetDays'] as num).toInt(),
        plannedMinutesPerDay: (j['plannedMinutesPerDay'] as num).toInt(),
        records: rec);
  }
}

// STORAGE KEYS
const String storageKey = 'zenciri_tasks_v1';

class HomePage extends StatefulWidget {
  final SharedPreferences prefs;
  const HomePage({super.key, required this.prefs});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Task> tasks = [];

  @override
  void initState() {
    super.initState();
    _loadTasks();
  }

  void _loadTasks() {
    final raw = widget.prefs.getString(storageKey );
    if (raw != null) {
      try {
        final list = jsonDecode(raw) as List<dynamic>;
        tasks = list.map((e) => Task.fromJson(e as Map<String, dynamic>)).toList();
      } catch (e) {
        tasks = [];
      }
    }
    setState(() {});
  }

  Future<void> _saveTasks() async {
    final encoded = jsonEncode(tasks.map((t) => t.toJson()).toList());
    await widget.prefs.setString(storageKey, encoded);
  }

  void _showCreateTask() {
    String title = '';
    int days = 21;
    int minutes = 10;
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
        builder: (ctx) {
          return Padding(
            padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Text('Yeni task əlavə et', style: Theme.of(context).textTheme.titleLarge),
                SizedBox(height: 12),
                TextField(
                  decoration: InputDecoration(labelText: 'Task adı'),
                  onChanged: (v) => title = v,
                ),
                Row(children: [
                  Expanded(
                      child: TextField(
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(labelText: 'Hədəf gün sayı'),
                    onChanged: (v) => days = int.tryParse(v) ?? days,
                  )),
                  SizedBox(width: 12),
                  Expanded(
                      child: TextField(
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(labelText: 'Gündə dəqiqə (plan)'),
                    onChanged: (v) => minutes = int.tryParse(v) ?? minutes,
                  )),
                ]),
                SizedBox(height: 12),
                Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                  TextButton(onPressed: () => Navigator.pop(ctx), child: Text('Ləğv et')),
                  ElevatedButton(
                      onPressed: () {
                        if (title.trim().isEmpty) return; // minimal validation
                        final t = Task(
                            id: DateTime.now().millisecondsSinceEpoch.toString(),
                            title: title.trim(),
                            createdAt: DateTime.now(),
                            targetDays: days,
                            plannedMinutesPerDay: minutes);
                        setState(() {
                          tasks.add(t);
                        });
                        _saveTasks();
                        Navigator.pop(ctx);
                      },
                      child: Text('Yarat')),
                ])
              ]),
            ),
          );
        });
  }

  void _openTask(Task task) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => TaskDetailPage(
                  task: task,
                  onUpdate: (updated) {
                    final idx = tasks.indexWhere((t) => t.id == updated.id);
                    if (idx != -1) {
                      setState(() => tasks[idx] = updated);
                      _saveTasks();
                    }
                  },
                  onDelete: () {
                    setState(() {
                      tasks.removeWhere((t) => t.id == task.id);
                    });
                    _saveTasks();
                    Navigator.pop(context);
                  },
                )));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Zənciri Qırmamaq')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showCreateTask,
        label: Text('Yeni task'),
        icon: Icon(Icons.add),
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: tasks.isEmpty
            ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.no_accounts, size: 72),
                SizedBox(height: 12),
                Text('Heç bir task yoxdur. Yeni task əlavə et və zənciri qırma!'),
              ]))
            : ListView.separated(
                itemCount: tasks.length,
                separatorBuilder: (_, __) => SizedBox(height: 8),
                itemBuilder: (ctx, i) {
                  final t = tasks[i];
                  final completedDays = t.records.values.where((m) => m > 0).length;
                  final progress = t.targetDays == 0 ? 0.0 : completedDays / t.targetDays;
                  final totalSpent = t.records.values.fold(0, (a, b) => a + b);
                  return Card(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () => _openTask(t),
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Row(children: [
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(t.title, style: Theme.of(context).textTheme.titleMedium),
                              SizedBox(height: 8),
                              LinearProgressIndicator(value: progress),
                              SizedBox(height: 8),
                              Row(children: [
                                Text('$completedDays / ${t.targetDays} gün tamamlandı'),
                                SizedBox(width: 12),
                                Text('Cəmi: $totalSpent dəq')
                              ])
                            ]),
                          ),
                          PopupMenuButton<String>(onSelected: (v) {
                            if (v == 'delete') {
                              showDialog(
                                  context: context,
                                  builder: (_) => AlertDialog(
                                        title: Text('Silinsin?'),
                                        content: Text('Bu taskı silmək istədiyinizə əminsiniz?'),
                                        actions: [
                                          TextButton(onPressed: () => Navigator.pop(context), child: Text('Xeyr')),
                                          TextButton(
                                              onPressed: () {
                                                setState(() => tasks.removeAt(i));
                                                _saveTasks();
                                                Navigator.pop(context);
                                              },
                                              child: Text('Bəli'))
                                        ],
                                      ));
                            }
                          }, itemBuilder: (_) => [PopupMenuItem(value: 'delete', child: Text('Sil'))])
                        ]),
                      ),
                    ),
                  );
                }),
      ),
    );
  }
}

class TaskDetailPage extends StatefulWidget {
  final Task task;
  final void Function(Task) onUpdate;
  final VoidCallback onDelete;
  const TaskDetailPage({super.key, required this.task, required this.onUpdate, required this.onDelete});

  @override
  State<TaskDetailPage> createState() => _TaskDetailPageState();
}

class _TaskDetailPageState extends State<TaskDetailPage> {
  late Task task;

  @override
  void initState() {
    super.initState();
    task = widget.task;
  }

  void _setRecord(int dayIndex, int minutes) {
    setState(() {
      if (minutes <= 0) {
        task.records.remove(dayIndex);
      } else {
        task.records[dayIndex] = minutes;
      }
    });
    widget.onUpdate(task);
  }

  int get totalMinutes => task.records.values.fold(0, (a, b) => a + b);

  @override
  Widget build(BuildContext context) {
    final days = List.generate(task.targetDays, (i) => i);
    final completed = task.records.values.where((m) => m > 0).length;
    final progress = task.targetDays == 0 ? 0.0 : completed / task.targetDays;

    return Scaffold(
      appBar: AppBar(
        title: Text(task.title),
        actions: [
          IconButton(
              onPressed: () {
                showModalBottomSheet(
                    context: context,
                    builder: (_) => Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(mainAxisSize: MainAxisSize.min, children: [
                            ListTile(title: Text('Plan: ${task.plannedMinutesPerDay} dəq/gün')),
                            ListTile(title: Text('Hədəf günlər: ${task.targetDays}')),
                            ListTile(title: Text('Başlama tarixi: ${task.createdAt.toLocal().toString().split(' ').first}')),
                            ListTile(title: Text('Cəmi sərf olunan: $totalMinutes dəq')),
                            SizedBox(height: 8),
                            ElevatedButton.icon(onPressed: widget.onDelete, icon: Icon(Icons.delete), label: Text('Taskı sil'))
                          ]),
                        ));
              },
              icon: Icon(Icons.info_outline))
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Proqres', style: Theme.of(context).textTheme.titleMedium),
          SizedBox(height: 8),
          Row(children: [
            Expanded(child: LinearProgressIndicator(value: progress, minHeight: 12)),
            SizedBox(width: 12),
            Text('${(progress * 100).round()}%')
          ]),
          SizedBox(height: 16),
          Text('Günlər', style: Theme.of(context).textTheme.titleMedium),
          SizedBox(height: 8),
          Expanded(
            child: GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, mainAxisExtent: 80, crossAxisSpacing: 8, mainAxisSpacing: 8),
                itemCount: days.length,
                itemBuilder: (ctx, idx) {
                  final m = task.records[idx] ?? 0;
                  final done = m > 0;
                  return GestureDetector(
                    onTap: () => _showRecordEditor(idx, m),
                    child: Container(
                      decoration: BoxDecoration(
                        color: done ? Colors.green.shade100 : Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: done ? Colors.green : Colors.grey.shade300, width: 1.5),
                      ),
                      padding: const EdgeInsets.all(8.0),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Text('Gün ${idx + 1}', style: TextStyle(fontWeight: FontWeight.bold)),
                        SizedBox(height: 6),
                        Text(done ? '$m dəq' : '—', style: TextStyle(fontSize: 12)),
                      ]),
                    ),
                  );
                }),
          ),
          SizedBox(height: 8),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Cəmi sərf olunan:'),
              Text('$totalMinutes dəq', style: Theme.of(context).textTheme.titleLarge),
            ]),
            ElevatedButton.icon(
                onPressed: () => _showQuickFillDialog(),
                icon: Icon(Icons.flash_on),
                label: Text('Tez doldur'))
          ])
        ]),
      ),
    );
  }

  void _showRecordEditor(int idx, int currentMinutes) {
    int minutes = currentMinutes;
    showDialog(
        context: context,
        builder: (_) => AlertDialog(
              title: Text('Gün ${idx + 1} — qeyd et'),
              content: Column(mainAxisSize: MainAxisSize.min, children: [
                TextField(
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(labelText: 'Sərf olunan dəqiqə (0 = yox)'),
                  controller: TextEditingController(text: currentMinutes == 0 ? '' : currentMinutes.toString()),
                  onChanged: (v) => minutes = int.tryParse(v) ?? 0,
                ),
                SizedBox(height: 8),
                Text('Planlanan: ${task.plannedMinutesPerDay} dəq')
              ]),
              actions: [
                TextButton(onPressed: () => Navigator.pop(context), child: Text('Ləğv')),
                TextButton(
                    onPressed: () {
                      _setRecord(idx, minutes);
                      Navigator.pop(context);
                    },
                    child: Text('Qeyd et'))
              ],
            ));
  }

  void _showQuickFillDialog() {
    // Fəaliyyət: istifadəçiyə bir kliklə əvvəlki boşları planlanan dəqiqə ilə doldurma imkanı verir
    showDialog(
        context: context,
        builder: (_) => AlertDialog(
              title: Text('Boş günləri tez doldur'),
              content: Text('Bütün doldurulmamış günləri planlanmış ${task.plannedMinutesPerDay} dəq ilə doldurmaq istəyirsiniz?'),
              actions: [
                TextButton(onPressed: () => Navigator.pop(context), child: Text('Xeyr')),
                TextButton(
                    onPressed: () {
                      for (int i = 0; i < task.targetDays; i++) {
                        if (!(task.records.containsKey(i) && (task.records[i] ?? 0) > 0)) {
                          task.records[i] = task.plannedMinutesPerDay;
                        }
                      }
                      widget.onUpdate(task);
                      Navigator.pop(context);
                      setState(() {});
                    },
                    child: Text('Bəli'))
              ],
            ));
  }
}

/*
NOTLAR / TƏKMİLLƏŞMƏ ÜÇÜN İDEYALAR:
- Sync (backup) üçün Google Drive/Cloud Firestore əlavə edə bilərsiniz.
- Daha mürəkkəb saxlanma üçün sqflite və ya hive istifadə edin.
- UI üçün daha modern görüntü: animations, Lottie animasiyaları, daha çox rəng seçimi.
- Lokalizasiya: app textlərini i18n-ə çevirin.

Bu faylı `lib/main.dart` olaraq saxlayın və `pubspec.yaml`-ı yuxarıdakı kimi düzəldin.

Əgər istəsəniz, mən sizə buradan tam release APK yaratmaq üçün lazım olan `key.properties` və `android/` içi konfiqurasiyalar da göstərə bilərəm, həmçinin UI dizaynı dəyişiklikləri edə bilərəm (rənglər, fontlar, iconlar).
*/

